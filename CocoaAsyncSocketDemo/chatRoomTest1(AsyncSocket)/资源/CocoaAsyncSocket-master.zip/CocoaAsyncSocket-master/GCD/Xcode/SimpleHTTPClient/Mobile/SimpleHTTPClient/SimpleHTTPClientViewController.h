#import <UIKit/UIKit.h>


@interface SimpleHTTPClientViewController : UIViewController {
    
}

@end
