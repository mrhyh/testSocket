#import <Foundation/Foundation.h>


@interface TestPreBuffer : NSObject

+ (void)start;

@end
