#import <UIKit/UIKit.h>


@interface ConnectTestViewController : UIViewController {
    
}

@property (nonatomic, strong) IBOutlet UILabel *label;

@end
