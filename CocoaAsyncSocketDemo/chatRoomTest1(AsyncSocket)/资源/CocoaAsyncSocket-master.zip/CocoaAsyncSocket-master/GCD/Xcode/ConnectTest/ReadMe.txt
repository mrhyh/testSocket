The ConnectTest projects demonstrates some of the various options available for connecting to a host, such as:

- Setting connect timeouts
- Connecting to secure hosts (using SSL/TLS)