//
//  InterfaceTestViewController.h
//  InterfaceTest
//
//  Created by Robbie Hanson on 10/15/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface InterfaceTestViewController : UIViewController {

}

@end

